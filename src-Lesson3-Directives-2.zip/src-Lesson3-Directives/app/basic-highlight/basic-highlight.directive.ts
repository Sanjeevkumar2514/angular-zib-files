import { Directive, OnInit, ElementRef } from '@angular/core';

//directives do not have templates like components....but sit on html elements and templates

@Directive({
  selector: '[appBasicHighlight]', //camel case and use as an attribute
})
export class BasicHighlightDirective implements OnInit {
  constructor(private elementRef: ElementRef) {}

  //  classname obj = new classname();

  ngOnInit() {
    this.elementRef.nativeElement.style.backgroundColor = 'red';
    this.elementRef.nativeElement.style.color = 'white';
    this.elementRef.nativeElement.style.fontSize = '20px';
    this.elementRef.nativeElement.style.fontWeight = 'bold';
  }
}
