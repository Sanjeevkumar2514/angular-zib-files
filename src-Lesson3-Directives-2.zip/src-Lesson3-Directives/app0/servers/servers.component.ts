import { Component, OnInit } from '@angular/core';

@Component({
  // selector: '[app-servers]',
  // selector: '.app-servers',
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css'],
})
export class ServersComponent implements OnInit {
  allowNewServer: boolean = false;
  serverCreationStatus = 'No server was created!';
  serverName = 'Testserver';
  serverCreated = false;
  servers = [
    'Testserver 1',
    'Testserver 2',
    'Testserver 3',
    'Testserver 4',
    'Testserver 5',
  ];
  serversNameValue = [
    { name: 'Testserver', capacity: 1000, status: 'online' },
    { name: 'Testserver 2', capacity: 1500, status: 'offline' },
    { name: 'Testserver 3', capacity: 2000, status: 'online' },
  ];

  /*
 function funcName(param1,param2) {
   body of the function with params
  }
//-------------------------------------
  ES Arrow Function
  (param1,param2) => {
   body of the function with params
  }
  */

  constructor() {
    setTimeout(() => {
      this.allowNewServer = true;
    }, 2000);
  }

  ngOnInit() {}

  onCreateServer() {
    this.serverCreated = true;
    this.servers.push(this.serverName);
    this.serverCreationStatus =
      'Server was created! Name is ' + this.serverName;
    this.serversNameValue.push({
      name: 'Testserver X',
      capacity: 1111,
      status: 'online',
    });
  }

  onUpdateServerName(event: Event) {
    this.serverName = (<HTMLInputElement>event.target).value;
  }

  // template: `
  //   <app-server></app-server>
  //   <app-server></app-server>`,
}
