import { Component } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  /*   styles: [
    `
      .onlineCls {
        color: cyan;
        font-size: 15px;
      }
    `,
  ], */
  styleUrls: ['./server.component.css'],
})
export class ServerComponent {
  serverId: number = 10;
  serverStatus: string = 'offline';

  constructor() {
    //this.serverStatus = Math.random() > 0.5 ? 'online' : 'offline'; //TERNARY OPERATOR

    let val = Math.random(); //0-1.0
    console.log('random val : ' + val);
    this.serverStatus = val > 0.5 ? 'online' : 'offline'; //TERNARY OPERATOR
    console.log('serverStatus : ' + this.serverStatus);

    //IF ELSE CONDITION
    /*  if(Math.random() > 0.5){
      this.serverStatus = 'online';
    }else{
      this.serverStatus = 'offline';
    } */
  }

  getServerStatus() {
    return this.serverStatus;
  }

  getColor() {
    return this.serverStatus === 'online' ? 'green' : 'red';
  }
}
