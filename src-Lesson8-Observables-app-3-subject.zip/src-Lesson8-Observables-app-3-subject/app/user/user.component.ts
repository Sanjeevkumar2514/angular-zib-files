import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { filter, map } from 'rxjs/operators';

import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  id!: number;
  trxns: any;

  constructor(
    private route: ActivatedRoute,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      //this.id = +params[0].id;
      //this.id = +params['id'];
      this.id = +params['id'];
    });
  }

  onActivate() {
    //USING EVENT EMITTER
    //this.userService.activatedEmitter.emit(true);

    //USING SUBJECT
    this.userService.activatedEmitter.next(true);
  }

  //----------------------------------------------------------------------------------------------
  /*   getTrxnsListDataX1() {
          this.userService.getTrxnsList().subscribe(
            data1 => {
                this.trxns = data1;
            },
            err => console.error(err),
            () => console.log('done loading stock list 2222222222222222222')
          );

          } */
  //-------------------------------------------------
  //MAP OPERATOR
  getTrxnsListDataX1() {
    this.userService
      .getTrxnsList()
      .pipe(
        map((data: any) => {
          let arr = [];
          for (let i = 0; i < data.length; i++) {
            //console.log('id : '+data[i].id);
            if (data[i].id % 2 === 0) {
              //console.log('IF :: '+ data[i].id);
            } else {
              arr.push({
                userId: data[i].userId + '- hello',
                id: data[i].id,
                title: data[i].title,
                completed: data[i].completed,
              });
            }
          }
          return arr;
        })
      )
      .subscribe(
        (data1) => {
          this.trxns = data1;
        },
        (err) => console.error(err),
        () => console.log('done loading stock list 2222222222222222222')
      );
  }
  //-------------------------------------------------
  //-------------------------------------------------
  //MAP OPERATOR
  getTrxnsListDataX2() {
    //this.userService.getTrxnsList().pipe(filter(data=>data[0].id === 1),map((data:any)=>{
    this.userService
      .getTrxnsList()
      .pipe(
        map((data: any) => {
          let arr = [];
          for (let i = 0; i < data.length; i++) {
            console.log('id : ' + data[i].id);
            if (data[i].id % 2 !== 0) {
              console.log('IF :: ' + data[i].id);
            } else {
              arr.push({
                userId: data[i].userId + '- hello',
                id: data[i].id,
                title: data[i].title,
                completed: data[i].completed,
              });
            }
          }
          return arr;
        })
      )
      .subscribe(
        (data1) => {
          this.trxns = data1;
        },
        (err) => console.error(err),
        () => console.log('done loading stock list 2222222222222222222')
      );
  }
  //-------------------------------------------------

  //FILTER OPERATOR
  getTrxnsListDataX3() {
    //this.userService.getTrxnsList().pipe(map((reports : IData[]) => reports.filter(p => p.id >5))).subscribe(

    this.userService
      .getTrxnsList()
      .pipe(map((reports: any) => reports.filter((p: any) => p.id > 5)))
      .subscribe(
        //this.userService.getTrxnsList().pipe(map((reports : IData[]) => reports.filter(p => p.completed === false))).subscribe(
        (data1) => {
          this.trxns = data1;
        },
        (err) => console.error(err),
        () => console.log('done loading stock list 2222222222222222222')
      );
  }
}

export interface IData {
  userId: number;
  id: number;
  title: string;
  completed: boolean;
}
