import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private http: HttpClient) {}

  //USING EVENT EIMITTER
  //activatedEmitter = new EventEmitter<boolean>();

  //USING SUBJECT
  activatedEmitter = new Subject<boolean>();

  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  getTrxnsList() {
    return this.http.get('https://jsonplaceholder.typicode.com/todos');
  }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}
