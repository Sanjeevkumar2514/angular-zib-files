import { Component, OnDestroy, OnInit } from '@angular/core';

import { interval, Subscription, Observable, Observer } from 'rxjs';
import { map, filter } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit, OnDestroy {
  private firstObsSubscription!: Subscription;

  constructor() {}

  ngOnInit() {
    //1111111111111111111111111
    /*  this.firstObsSubscription = interval(1000).subscribe((count) => {
      console.log(count);
    }); */
    //------------------------------------------------------------------
    //222222222222222222222222
    const customIntervalObservable = Observable.create(
      (observer: Observer<string>) => {
        let count: any = 0;
        setInterval(() => {
          //if (count > 3) {
          // observer.error(new Error('Count is greater 3!'));
          //}
          observer.next(count);
          if (count === 5) {
            observer.complete();
          }
          count++;
        }, 1000);
      }
    );
    //------------------------------------------------------------------

    //MAP
    /* this.firstObsSubscription = customIntervalObservable
      .pipe(
        map((data: number) => {
          return 'Round: ' + data;
        })
      )
      .subscribe(
        (data: any) => {
          console.log(data);
        },
        (error: any) => {
          console.log(error);
          alert(error.message);
        },
        () => {
          console.log('Completed!');
        }
      ); */

    //========================================================
    //FILTER AND MAP
    /*  this.firstObsSubscription = customIntervalObservable
      .pipe(
        filter((data: any) => {
          return data > 2;
        }),
        map((data: number) => {
          return 'Round: ' + data;
        })
      )
      .subscribe(
        (data: any) => {
          console.log(data);
        },
        (error: any) => {
          console.log(error);
          alert(error.message);
        },
        () => {
          console.log('Completed!');
        }
      ); */
    //========================================================
  }

  ngOnDestroy(): void {
    this.firstObsSubscription.unsubscribe();
  }
}
