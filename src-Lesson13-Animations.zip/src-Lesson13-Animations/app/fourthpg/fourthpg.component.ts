import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fourthpg',
  templateUrl: './fourthpg.component.html',
  styleUrls: ['./fourthpg.component.css']
})
export class FourthpgComponent implements OnInit {

  constructor() { 
    console.log('inside 4th page');
  }

  ngOnInit(): void {
  }

}
