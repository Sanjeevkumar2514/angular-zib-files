export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyBVSO7hSVerw09QOdK454X0ne1n2gDOMLI',
    authDomain: 'angg14app.firebaseapp.com',
    databaseURL:
      'https://angg14app-default-rtdb.asia-southeast1.firebasedatabase.app',
    projectId: 'angg14app',
    storageBucket: 'angg14app.appspot.com',
    messagingSenderId: '922151707705',
    appId: '1:922151707705:web:f546744b20363f422d19e8',
  },
};
