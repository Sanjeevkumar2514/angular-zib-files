export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCVNh5d2eqcE1Sha6b926XQAc-JbZfNH0w',
    authDomain: 'angular-ng-http-b6f44.firebaseapp.com',
    databaseURL: 'https://angular-ng-http-b6f44.firebaseio.com',
    projectId: 'angular-ng-http-b6f44',
    storageBucket: 'angular-ng-http-b6f44.appspot.com',
    messagingSenderId: '106798384575',
    appId: '1:106798384575:web:9eda76ce6a88516de18d0a',
  },
};
