import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse',
})
export class ReversePipe implements PipeTransform {
  transform(value: any): any {
    return value.split('').reverse().join('');
  }
}
//hello
//h e l l 0 - SPLIT INTO ARRAY ITEMS
//o l l e h - REVERSE
//olleh - JOIN
