import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  username = 'hello how are you';
  username1 = 'RAJESH';
  datee = new Date(2022, 7, 16); //month starts from 0
  //datee = new Date(2022, 7, 24, 10, 33, 30, 0);
  /*  datee = new Date(2022, 7, 16, 10, 33, 30, 0).toLocaleString(undefined, {
    timeZone: 'Asia/Kolkata',
  }); */
  /*  datee = new Date('2022-08-16T17:43:37.000Z').toLocaleString(undefined, {
    timeZone: 'Asia/Kolkata',
  }); */
  amount = 12500.5164;
  appStatus = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('stable');
    }, 3000);
  });

  servers = [
    {
      instanceType: 'large',
      name: 'User Database',
      status: 'stable',
      started: new Date(2022, 7, 16),
    },
    {
      instanceType: 'large2',
      name: 'User Database2',
      status: 'stable',
      started: new Date(2022, 7, 16),
    },
    {
      instanceType: 'medium',
      name: 'Testing Environment Server',
      status: 'critical',
      started: new Date(2022, 7, 16),
    },
    {
      instanceType: 'small',
      name: 'Development Server',
      status: 'offline',
      started: new Date(2022, 7, 16),
    },
  ];

  filteredStatus = '';
  getStatusClasses(server: {
    instanceType: string;
    name: string;
    status: string;
    started: Date;
  }) {
    return {
      'list-group-item-success': server.status === 'stable',
      'list-group-item-warning': server.status === 'offline',
      'list-group-item-danger': server.status === 'critical',
    };
  }
  onAddServer() {
    this.servers.push({
      instanceType: 'small',
      name: 'New Server',
      status: 'stable',
      started: new Date(2022, 7, 16),
    });
  }
}
