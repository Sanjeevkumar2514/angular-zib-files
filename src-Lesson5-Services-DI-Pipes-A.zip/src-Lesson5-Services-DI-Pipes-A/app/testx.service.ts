import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TestxService {
  constructor() {}

  func1() {
    return 'func1';
  }
  func2() {
    return 'func2';
  }
  func3() {
    return 'func3';
  }
  func4() {
    return 'func4';
  }
}
