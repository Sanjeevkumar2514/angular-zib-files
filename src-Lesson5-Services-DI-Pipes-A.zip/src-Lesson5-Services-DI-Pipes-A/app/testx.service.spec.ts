import { TestBed } from '@angular/core/testing';

import { TestxService } from './testx.service';

describe('TestxService', () => {
  let service: TestxService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TestxService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
