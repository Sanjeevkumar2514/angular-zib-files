import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class OurserviceService {
  constructor(private http: HttpClient) {}

  ourFunction(x: any, y: any) {
    return x * y;
  }
}
