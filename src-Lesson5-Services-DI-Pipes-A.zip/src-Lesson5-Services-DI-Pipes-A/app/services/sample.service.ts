import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SampleService {
  constructor() {}
  mySampleFunction() {
    return 'data from mySampleFunction';
  }
  wwww() {
    return 'data from mySampleFunction';
  }
}
//ng g s services/sample
