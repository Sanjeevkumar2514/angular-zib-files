import { TestBed } from '@angular/core/testing';

import { OurserviceService } from './ourservice.service';

describe('OurserviceService', () => {
  let service: OurserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OurserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
