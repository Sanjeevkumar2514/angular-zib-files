import { Injectable } from '@angular/core';
import { LoggingService } from '../logging.service';

@Injectable()
export class TestserviceService {
  constructor(private loggingService: LoggingService) {}

  testFunction() {
    this.loggingService.logSomeText('inside testFunction');
    return 45 + 23;
  }

  testFunction2() {
    return 45 + 100;
  }
}
//ng generate service testservice
