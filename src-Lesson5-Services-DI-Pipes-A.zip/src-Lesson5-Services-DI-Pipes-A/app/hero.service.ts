import { Injectable, OnInit } from '@angular/core';
import { LoggerService } from './logger.service';

@Injectable({
  providedIn: 'root',
})
export class HeroService implements OnInit {
  HEROES = [
    { name: 'Ramesh', age: '45', qualification: 'Engineer' },
    { name: 'Rajesh', age: '42', qualification: 'Doctor' },
    { name: 'Kiran', age: '33', qualification: 'Painter' },
  ];

  constructor(private logger: LoggerService) {}

  ngOnInit() {}

  getHeroes() {
    this.logger.log('Getting heroes ...');
    return this.HEROES;
  }
}
