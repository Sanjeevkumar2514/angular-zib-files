export class LoggingService {
  
  logSomeText(msg:string) {
    console.log('LOGGING: ' + msg);
  }
}
