import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/';
import { HttpClient } from '@angular/common/http';

@Injectable(/* {
  providedIn:'root'
} */)
export class MyservicediService {
  heros = [
    { name: 'ramesh', age: 45 },
    { name: 'ganesh', age: 32 },
    { name: 'Raju', age: 22 },
    { name: 'Gopi', age: 55 },
    { name: 'Peter', age: 76 },
    { name: 'John', age: 25 },
  ];

  constructor(private http: HttpClient) {}
  getHeroes() {
    return this.heros;
  }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  getTrxnsList() {
    return this.http.get('https://jsonplaceholder.typicode.com/todos');
  }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}
