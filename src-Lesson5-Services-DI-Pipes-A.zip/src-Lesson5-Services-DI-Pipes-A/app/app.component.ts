import { Component, OnInit } from '@angular/core';
import { MyservicediService } from './myservicedi/myservicedi.service';

import { HttpClient } from '@angular/common/http';
import { OurserviceService } from './services/ourservice.service';
import { HeroService } from './hero.service';
import { TestxService } from './testx.service';
import { TestserviceService } from './testservice/testservice.service';
import { LoggingService } from './logging.service';
import { LoggerService } from './logger.service';
import { SampleService } from './services/sample.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  //providers:[MyservicediService]
})
export class AppComponent implements OnInit {
  title = 'Services and DI';
  strFromSampleService;
  testfunctionVal;
  testfunctionVal1 = 0;
  ourVal;
  heros: any = [];
  trxns: any;
  herosx: any = [];

  constructor(
    private sampleservice: SampleService, //dependency injection
    private hero: HeroService,
    private http: HttpClient,
    private myservicediService: MyservicediService,
    private testserviceService: TestserviceService,
    private ourserviceService: OurserviceService,
    private testxService: TestxService, //dependency injection
    private loggingService: LoggingService,
    private loggerService: LoggerService
  ) {
    /*   let strValFromSampleService = this.sampleservice.mySampleFunction();
    console.log(strValFromSampleService); */
    this.strFromSampleService = this.sampleservice.mySampleFunction();

    console.log(this.testxService.func1());
    console.log(this.testxService.func2());

    //11111111111111111111111111111111111111111111
    this.testfunctionVal1 = this.testserviceService.testFunction();
    this.testfunctionVal = this.testserviceService.testFunction2();
    this.ourVal = this.ourserviceService.ourFunction(9, 8);
    console.log(this.ourVal);

    //22222222222222222222222222222222222222222222
    this.heros = this.myservicediService.getHeroes();

    //-------------------------------------------------
    this.herosx = this.hero.getHeroes();
    console.log(JSON.stringify(this.herosx));
    //-------------------------------------------------
  }
  ngOnInit(): void {
    console.log(
      this.loggingService.logSomeText(
        'SOME TEXT FROM  == LOGGING == SERVICE TO CONSOLE...'
      )
    );

    //-------------------------------------------------
    console.log(
      this.loggerService.log(
        'SOME TEXT FROM == LOGGER == SERVICE TO CONSOLE...'
      )
    );
  }
  //----------------------------------------------------------------------------------------------

  getTrxnsListData() {
    this.myservicediService.getTrxnsList().subscribe(
      (data) => {
        console.log(' DATA ARRIVED : ' + JSON.stringify(data));
        console.log(data);
        this.trxns = data;
      },
      (err) => console.error(err),
      () => console.log('done loading stock list 2222222222222222222')
    );
    ///this.trxns = this.myservicediService.getTrxnsList();
  }
  //-------------------------------------------------
}
