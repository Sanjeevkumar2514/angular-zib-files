import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import { ProductService } from './product.service';
import { Product } from './product';


@Component({ 
   template: `<h3> Specification Page<h3>`
})

export class ProductSpecComponent
{
   constructor(){
   }


   ngOnInit() {  
   }
   
}