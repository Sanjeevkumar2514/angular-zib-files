import { Component } from '@angular/core';

@Component({
  template: `<h1
      style="background:red;padding:10px;border:1px solid navy;color:white;font-size:20px"
    >
      Oops! you have entered wrong url...
    </h1>
    <h2
      style="background:pink;padding:10px;border:1px solid red;font-size:20px;color:red"
    >
      Please try again..
    </h2> `,
})
export class ErrorComponent {}
