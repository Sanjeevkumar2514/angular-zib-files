import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';


@Component({
  template: `<h3> Overview Page<h3>`
})

export class ProductOverviewComponent
{

   constructor(){
   }


   ngOnInit() {    
   }

 
}