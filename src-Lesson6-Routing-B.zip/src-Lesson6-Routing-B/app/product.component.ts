import { Component, OnInit } from '@angular/core';

import { ProductService } from './product.service';
import { Product } from './product';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  templateUrl: './product.component.html',
})
export class ProductComponent {
  public paramsDataSpecial: any;
  tenantdetails: any;

  products: Product[] = [];

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    //-------------------------- NAVIGATION EXTRAS ARRAY---------------------------------------
    this.route.queryParams.subscribe((params) => {
      if (params && params['special']) {
        this.paramsDataSpecial = JSON.parse(params['special']);
        console.log(
          'TENANT DETAILS FROM PARAMS :: ' +
            JSON.stringify(this.paramsDataSpecial)
        );

        this.tenantdetails = this.paramsDataSpecial.tenantdetails;

        for (let i = 0; i < this.tenantdetails.length; i++) {
          console.log('id :: ' + this.tenantdetails[i].id);
          console.log(
            'selectedpropertyid :: ' + this.tenantdetails[i].selectedpropertyid
          );
          console.log('field3 :: ' + this.tenantdetails[i].field);
        }
      }
    });
    //-------------------------- NAVIGATION EXTRAS ARRAY---------------------------------------
  }

  ngOnInit() {
    this.products = this.productService.getProducts();
  }
}
