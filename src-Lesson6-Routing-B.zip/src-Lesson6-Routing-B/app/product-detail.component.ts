import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';

import { ProductService } from './product.service';
import { Product } from './product';

@Component({
  templateUrl: './product-detail.component.html',
  styles: [
    `
      table {
        width: 100%;
      }
      table,
      th,
      td {
        border: 1px solid black;
        border-collapse: collapse;
      }
      th,
      td {
        padding: 15px;
        text-align: center;
      }
      #t01 tr {
        background-color: #fff;
      }
      #t01 th {
        background-color: orange;
        color: white;
      }
    `,
  ],
})
export class ProductDetailComponent {
  product: any;
  id: any;
  sub: any;

  constructor(
    private _Activatedroute: ActivatedRoute,
    private _router: Router,
    private _productService: ProductService
  ) {}

  ngOnInit() {
    this.sub = this._Activatedroute.params.subscribe((params) => {
      console.log('PRODUCT DETAIL IIIDDDD :: ' + params['id']);
      this.id = params['id'];
      let products = this._productService.getProducts();
      console.log('PRODUCT DETAIL ---->' + JSON.stringify(products));
      this.product = products.find((p) => p.productID == this.id);
    });
  }
  onBack(): void {
    //console.log(this._router.routerState);
    //this._router.navigate(['product']);
    //this._router.navigateByUrl('product');

    //-------------------------- NAVIGATION EXTRAS ---------------------------------------

    let tenantdetails = {
      id: 1234,
      selectedpropertyid: 5678,
      field: 'This is another parameter',
    };
    let paramsTenantdetails = { tenantdetails: tenantdetails };

    //-------------------------- NAVIGATION EXTRAS ---------------------------------------
    //-------------------------- NAVIGATION EXTRAS ARRAY---------------------------------------
    let tenantdetailsArr = [
      {
        id: 11111,
        selectedpropertyid: 1234,
        field: 'This is first parameter',
      },
      {
        id: 22222,
        selectedpropertyid: 5678,
        field: 'This is second parameter',
      },
    ];
    let paramsTenantdetailsArr = { tenantdetails: tenantdetailsArr };
    //-------------------------- NAVIGATION EXTRAS ARRAY---------------------------------------
    let navigationExtras: NavigationExtras = {
      queryParams: {
        special: JSON.stringify(paramsTenantdetails),
        //special: JSON.stringify(paramsTenantdetailsArr),
      },
    };
    this._router.navigate(['product'], navigationExtras);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
