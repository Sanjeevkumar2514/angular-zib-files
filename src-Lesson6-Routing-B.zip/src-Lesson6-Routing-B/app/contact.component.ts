import { Component } from '@angular/core';

@Component({
  template: `<h1>Contact Us</h1>
    <p>Angular 14</p> `,
})
export class ContactComponent {}
