import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposita',
  template: `
  <div style="border:2px solid red;margin-top:10px;box-shadow: 5px 10px #888888;">
    <p style="font-size:40px;color:navy">
      Put the coins inside the blinking container!
    </p>
    </div>
  `,
  styles: [
  ]
})
export class DepositaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
