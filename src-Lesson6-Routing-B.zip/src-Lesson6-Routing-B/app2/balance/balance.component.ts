import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance',
  template: `
  <div style="border:2px solid navy;margin-top:10px;box-shadow: 5px 10px #888888;padding:10px;color:green;font-weight:bold">
      Your account balance is $4,548
    </div>
  `,
  styles: [
  ]
})
export class BalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
