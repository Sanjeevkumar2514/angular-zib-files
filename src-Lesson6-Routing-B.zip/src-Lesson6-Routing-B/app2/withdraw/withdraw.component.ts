import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdraw',
  template: `
  
    <div style="border:2px solid navy;margin-top:10px;box-shadow: 5px 10px #888888;padding:10px;color:red;font-weight:bold">
      Unable to dispense cash at the moment, sorry.
      </div>
  
  `,
  styles: [
  ]
})
export class WithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
