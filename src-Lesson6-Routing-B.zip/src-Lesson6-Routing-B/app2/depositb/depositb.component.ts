import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-depositb',
  template: `
  <div style="border:2px solid orange;margin-top:10px;box-shadow: 5px 10px #888888;">
    <p style="font-size:40px;color:red">
      straighten and insert cash here!
    </p>
    </div>
  `,
  styles: [
  ]
})
export class DepositbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
