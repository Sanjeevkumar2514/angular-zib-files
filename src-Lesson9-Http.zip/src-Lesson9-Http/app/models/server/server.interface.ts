export interface Server{
    name:string;
    capacity:number;
    id:number;
}