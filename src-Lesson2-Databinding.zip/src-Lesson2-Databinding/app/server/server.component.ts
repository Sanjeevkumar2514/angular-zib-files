import { Component } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
})
export class ServerComponent {
  serverId: number;
  serverStatus: string = 'offline';

  getServerStatus() {
    this.serverId = 100;
    return this.serverStatus;
  }

  //NOTE:
  //ADD THE FOLLOWING IN "E:\Angular14-training\andV14Appx\tsconfig.json" - FILE
  //TO AVOID INITIALIZATION CHECK BY TS COMPILER IN VISUAL STUDIO CODE EDITOR.
  /*
  "strictNullChecks":false,
  "noImplicitAny":false,
  */
}
