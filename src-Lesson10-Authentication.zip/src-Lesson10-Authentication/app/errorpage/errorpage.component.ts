import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-errorpage',
  templateUrl: './errorpage.component.html',
  styleUrls: ['./errorpage.component.css'],
})
export class ErrorpageComponent implements OnInit {
  errMsg: string = '';
  errDesc: string = '';
  public paramsDataSpecial: any;
  constructor(private route: ActivatedRoute) {
    //----------------------------- EXTRACTING PARAMS DATA FROM NAVIGATOR EXTRAS -----------------------------------------
    this.route.queryParams.subscribe((params) => {
      if (params && params['special']) {
        console.log(params['special']);
        this.paramsDataSpecial = JSON.parse(params['special']);
        let errorsAll = [];
        errorsAll = this.paramsDataSpecial;
        this.errMsg = errorsAll[0].errMsg;
        this.errDesc = JSON.stringify(errorsAll[1].errDesc);
      } else {
        console.log('NO PARAMS FROM NAVIGATOR EXTRAS...');
      }
    });
    //----------------------------- EXTRACTING PARAMS DATA FROM NAVIGATOR EXTRAS -----------------------------------------
  }

  ngOnInit() {}
}
