import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import 'rxjs';
import { Recipe } from './recipe.model';
import { Ingredient } from './ingredient.model';
import { DataStorageService } from './data-storage.service';
import { map } from 'rxjs/operators';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-showapp',
  templateUrl: './showapp.component.html',
  styleUrls: ['./showapp.component.css'],
})
export class ShowappComponent implements OnInit {
  public paramsDataSpecial: any;
  token!: string;

  constructor(
    private authService: AuthService,
    private http: HttpClient,
    private datastorageService: DataStorageService,
    private route: ActivatedRoute,
    private router: Router
  ) {} //CONSTRUCTOR ENDS

  ngOnInit() {}

  public recipes!: Recipe[];

  storeRecipes() {
    //-------------------------------------------------------
    this.recipes = [
      new Recipe(
        'Tasty Dum Biryani',
        'A super-tasty Schnitzel - just awesome ones!',
        'https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG',
        [new Ingredient('Meat', 1), new Ingredient('French Fries', 20)]
      ),
      new Recipe(
        'Big Fat Burger',
        'What else you need to say?',
        'https://upload.wikimedia.org/wikipedia/commons/b/be/Burger_King_Angus_Bacon_%26_Cheese_Steak_Burger.jpg',
        [new Ingredient('Buns', 2), new Ingredient('Meat', 1)]
      ),
    ];
    //-------------------------------------------------------
    this.datastorageService.storeRecipes(this.recipes).subscribe(
      (response) => console.log(response),
      (error) => console.log(error)
    );
    //no need to unscribe this observable as we will get only one observable and angular will clear it for us
  }

  getRecipes() {
    const token = this.authService.getToken();
    alert('getRecipes - token 222 --->: ' + token);
    let recipes: Recipe[];

    //WITH TOKEN
    this.http
      .get(environment.fbUrl + 'recipes.json?auth=' + token)

      //WITHOUT TOKEN
      /* this.http
      .get(environment.fbUrl + 'recipes.json') */

      .pipe(
        map((responseData) => {
          console.log(
            'responseData showappComponent : ' + JSON.stringify(responseData)
          );
          const postsArray = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              postsArray.push({ ...responseData[key] });
            }
          }
          this.recipes = postsArray;
        })
      )
      .subscribe(
        () => {},
        (error) => {
          console.log(error);
          alert(JSON.stringify(error));

          //----------------------------- SETTING PARAMS DATA FROM NAVIGATOR EXTRAS -----------------------------------------
          //Array....................
          let params = [{ errMsg: 'INVALID TOKEN' }, { errDesc: error }];
          //Array....................
          let navigationExtras: NavigationExtras = {
            queryParams: {
              special: JSON.stringify(params),
            },
          };
          this.router.navigate(['errorpage'], navigationExtras);
          //----------------------------- SETTING PARAMS DATA FROM NAVIGATOR EXTRAS -----------------------------------------
        }
      );
  }
}
